package javaapplication;

import java.sql.SQLException;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author Julio Bill Schvenger
 */
public class JavaApplication {
    public static void main(String[] args) throws UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException 
    {
        javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        JFrame_0001 nf = new JFrame_0001();
        nf.setTitle("Projeto pra testar a conexão com o SQL Server");
        nf.setLocationRelativeTo(null);
        nf.show();
    }
}